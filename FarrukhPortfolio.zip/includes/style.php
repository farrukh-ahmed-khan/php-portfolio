<link rel="stylesheet" href="assets/css/layout.css">
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/about.css">
<link rel="stylesheet" href="assets/css/contact.css">
<link rel="stylesheet" href="assets/css/services.css">
<link rel="stylesheet" href="assets/css/work.css">
<link rel="stylesheet" href="assets/css/enhancements.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

<link rel="shortcut icon" href="assets/images/" type="image/x-icon">
<link rel="icon" href="assets/images/" type="image/x-icon">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;600;700&display=swap" rel="stylesheet">
